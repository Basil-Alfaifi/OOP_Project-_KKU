package sem451;
public interface FileNames {
    final static String SESSIONS_FILE = "sessions.data";
    final static String PRINT_FILE = "printedData.txt";
    final static String PEOPLE_FILE = "people.data";
}
